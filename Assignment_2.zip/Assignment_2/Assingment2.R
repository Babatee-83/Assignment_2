
# Load required library
library(readr)

# Unzip and read the CSV file
unzip("Employee_Profile.zip")
csv_file <- list.files(pattern = "*.csv")[1]
employee_data <- read_csv(csv_file)

# Display the data
print(employee_data)

# Clean up extracted CSV file
file.remove(csv_file)
```